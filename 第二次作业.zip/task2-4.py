import math
eps = float(input())
i = 0
sum = 0
pai = 0
per = 0
while 1:
    per = (-1)**i / (2 * i + 1)
    sum += per
    pai = sum * 4
    if abs(per) <= eps:
        break
    i+=1
print(f"{pai:.6f}")
